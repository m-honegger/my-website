package suchenUndSortieren;
//import suchenUndSortieren.BinarySearch;
import java.util.*;

public class SortingAlgorithms {
	public static void main(String[] args) {
		int[] input = {67, 3, 905, 7 ,23, 12, -45, 78, 90, 34, 12, 76, 23};
		int[] sorted1 = bubbleSort(input);
		for(int i = 0; i < input.length; i++) {
			System.out.print(sorted1[i] + " ");
		}
		System.out.println();
		int[] sorted2 = selectionSort(input);
		for(int i = 0; i < input.length; i++) {
			System.out.print(sorted2[i] + " ");
		}
		System.out.println();
		int[] sorted3 = insertionSort(input);
		for(int i = 0; i < input.length; i++) {
			System.out.print(sorted3[i] + " ");
		}
		System.out.println();
		int[] sorted4 = mergeSort(input, 0, input.length-1);
		for(int i = 0; i < input.length; i++) {
			System.out.print(sorted4[i] + " ");
		}
		System.out.println();
		int[] sorted5 = heapSort(input);
		for(int i = 0; i < input.length; i++) {
			System.out.print(sorted5[i] + " ");
		}
		int[] weirdlySortedArray = {8,9,1,2,3,4,5,6,7};
		int x =findPivot(weirdlySortedArray, 0 ,weirdlySortedArray.length-1);
		System.out.println(x);
		
	}
	
	public static int linearSearch(int[] arr, int x) {
		for(int i = 0; i < arr.length; i++) {
			if(arr[i] == x) {
				return i;
			}
		}
		return -1;
	}
	
	public static int binarySearch(int arr[], int l, int r, int x) {
        if (r >= l) {
            int mid = l + (r - l) / 2;
            if (arr[mid] == x)
                return mid;
            if (arr[mid] > x)
                return binarySearch(arr, l, mid - 1, x);
            return binarySearch(arr, mid + 1, r, x);
        }
        return -1;
    }
	
	
	public static int[] bubbleSort(int[] arr) {
		for(int i = 0; i < arr.length-1; i++) {
			for(int j = 0; j < arr.length-1; j++) {
				if(arr[j] > arr[j+1]) {
					int tmp = arr[j+1];
					arr[j+1] = arr[j];
					arr[j] = tmp;
				}
			}
		}
		return arr;
	}
	
	public static int[] selectionSort(int[] arr) {
		for(int i = 0; i < arr.length; i++) {
			int max = Integer.MIN_VALUE;
			for (int j = 0; j < arr.length-i; j++) {
				if(arr[j] > max) {
					max = j;
				}
			}
			int tmp = arr[arr.length-i-1];
			arr[arr.length-i-1] = arr[max];
			arr[max] = tmp;
		}
		return arr;
	}
	
	public static int[] insertionSort(int[] arr) {
		int tmp1;
		int tmp2;
		for(int i = 0; i < arr.length-1; i++) {
			int index = BinarySearch.searchRecursive(arr, arr[i+1], 0, i);
			tmp1 = arr[index];
			arr[index] = arr[i];
			for(int j = index+1; j < i+1; j++) {
				tmp2 = arr[j];
				arr[j] = tmp1;
				tmp1 = tmp2;
			}
		}
		return arr;
	}
	
	public static int[] mergeSort(int[] arr, int l, int r) {
		if(l < r) {
			int mid = (l+r)/2;
			mergeSort(arr, l, mid);
			mergeSort(arr, mid+1,r);
			merge(arr,l,mid,r);
		}
		return arr;
	}
	
	public static int[] merge(int[] arr, int l, int mid, int r) {
		int[] B = new int[r-l+1];
		int i = l;
		int j = mid + 1;
		int k = 0;
		while( i <= mid && j <= r) {
			if(arr[i] <= arr[j]) {
				B[k] = arr[i];
				i++;
			}else {
				B[k] = arr[j];
				j++;
			}
			k++;
		}
		while(i<=mid) {
			B[k] = arr[i];
			i++;
			k++;
		}
		while(j<=r) {
			B[k] = arr[j];
			j++;
			k++;
		}
		return B;
	}
	
	public static int[] heapSort(int[] arr) {
		for(int i = arr.length/2; i >= 0; i--) {
			restoreHeapCondition(arr, i, arr.length);
		}
		for(int i = arr.length-1; i >= 1; i--) {
			int tmp = arr[0];
			arr[0] = arr[i];
			arr[i] = tmp;
			restoreHeapCondition(arr, 0, i);
		}
		
		return arr;
	}
	
	public static int[] restoreHeapCondition(int[] arr, int i, int n) {
		int j;
		while(2*i < n) {
			j = 2*i;
			if(j+1<n) {
				if(arr[j] < arr[j+1]) {
					j++;
				}
			}
			if(arr[i] >= arr[j]) {
				break;
			}
			int tmp = arr[i];
			arr[i] = arr[j];
			arr[j] = tmp;
			i = j;
		}
		return arr;
	}
	
	int partition(int arr[], int low, int high)
    {
        int pivot = arr[high]; 
        int i = (low-1);
        for (int j=low; j<high; j++){
            if (arr[j] < pivot){
                i++;
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
        int temp = arr[i+1];
        arr[i+1] = arr[high];
        arr[high] = temp;

        return i+1;
    }

    void sort(int arr[], int low, int high){
        if (low < high){
            int pi = partition(arr, low, high);
            sort(arr, low, pi-1);
            sort(arr, pi+1, high);
        }
    }
	
	public static int findPivot(int[] A, int l, int r) {
		while(l <= r) {
			int mid = (l+r)/2;
			if(A[mid]>A[mid+1]) {
				return mid;
			}else if(A[mid]>A[A.length-1]){
				l=mid+1;
			}else {
				r = mid-1;
			}
		}
		return -1;
	}
	
	public static int searchInWeirdSort(int[] A, int l) {
		int k = findPivot(A, 0, A.length-1);
		int low = l <= A[1] ? 1:k+1;
		int left = 0;
		int right = A.length-1;
		while(left < right) {
			int mid = (left+right)/2;
			 
		}
		return -1;
	}
    	

}
