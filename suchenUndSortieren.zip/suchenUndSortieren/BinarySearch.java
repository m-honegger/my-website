package suchenUndSortieren;

public class BinarySearch {
	public static void main(String[] args) {
		int[] input = {-4, 4, 6, 9, 45, 79, 103, 347, 901, 1253, 3956, 4056, 4567 };
		int x = 45;
		System.out.println(searchIterative(input,x));
		System.out.println(searchRecursive(input,x, 0, input.length));
	}
	
	public static int searchIterative(int[] arr, int x) {
		int left = 0; 
		int right = arr.length;
		int mid;
		while(left < right) {
			mid = (left + right)/2;
			if(arr[mid] == x) {
				return mid;
			}else if(arr[mid] < x) {
				left = mid + 1;
			}else {
				right = mid -1;
			}
		}
		return -1;
	}
	
	public static int searchRecursive(int[] arr,int x, int l, int r) {
		if(l < r) {
			int mid = (l+r)/2;
			if(arr[mid] == x) {
				return mid;
			}else if(arr[mid] > x){
				return searchRecursive(arr,x, l, mid-1);
			}else {
				return searchRecursive(arr, x, mid+1, r);
			}
		}
		return l;
	}
}
